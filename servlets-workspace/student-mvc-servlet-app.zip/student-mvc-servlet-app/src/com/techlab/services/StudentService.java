package com.techlab.services;

import java.sql.SQLException;
import java.util.List;

import com.techlab.dbservice.IStudentService;
import com.techlab.dbservice.StudentDbService;
import com.techlab.model.Student;

public class StudentService
{
	private IStudentService service;
	
	public StudentService() throws Exception
	{
		service = new StudentDbService();
	}
	
	public List<Student> getStudents() throws Exception
	{
		return service.getStudents();
	}
	
	public void addStudent(Student student) throws SQLException
	{
		service.addStudent(student);
	}

	public void updateStudent(Student student) throws SQLException
	{
		service.updateStudent(student);
	}

	public void deleteStudent(String id) throws SQLException
	{
		service.deleteStudent(id);
	}
	
}
