package com.techlab.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techlab.model.Student;
import com.techlab.services.StudentService;
import com.techlab.services.StudentServiceFactory;

@WebServlet("/home")
public class HomeController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	
	private StudentService service;

    public HomeController() throws Exception 
    {
    	 service = StudentServiceFactory.getStudentService();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			request.setAttribute("studentList", service.getStudents());
			RequestDispatcher view = request.getRequestDispatcher("WEB-INF/views/home.jsp");
			view.forward(request, response);
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String operation = request.getParameter("operation");
		
		switch (operation)
		{
			case "edit":
				String UUID = request.getParameter("guid");
				String name = request.getParameter("name");
				int rollNo = Integer.parseInt(request.getParameter("rollNo"));
				double cgpa = Double.parseDouble(request.getParameter("cgpa"));
				String location = request.getParameter("location");
				
				Student student = new Student(UUID, name, rollNo, cgpa, location);
				HttpSession session = request.getSession();
				session.setAttribute("studentToEdit", student);
				response.sendRedirect("http://localhost:8080/student-mvc-servlet-app/edit");
				break;
			case "delete":
				try
				{
					String GUID = request.getParameter("guid");
					service.deleteStudent(GUID);
					response.sendRedirect("http://localhost:8080/student-mvc-servlet-app/home");
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				break;
		}
	}

}
